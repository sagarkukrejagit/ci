function showPassword() {
  var x = document.getElementById("passwordInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

var count = 60, timer = setInterval(function() {
$("#timer").html(count--);
if(count == 1) clearInterval(timer);
}, 1000);
 $("#multiSelect").select2();
$(document).ready(function() {
    var table = $('#distributorTable').DataTable( {
        lengthChange: true,
        language: {  
        	"search": "_INPUT_",
        	"searchPlaceholder": "Search by Distributor Name or Mobile No.",
        	"lengthMenu":' <div class="select-box"><select class="form-control">'+
						      '<option value="10">10 per page</option>'+
						      '<option value="20">20 per page</option>'+
						      '<option value="30">30 per page</option>'+
						      '<option value="40">40 per page</option>'+
						      '<option value="50">50 per page</option>'+
						      '<option value="-1">All</option>'+
						      '</select></div> ',
			paginate: {
				      next: '<i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>',
				      previous: '<i class="fa fa-angle-left fa-lg" aria-hidden="true"></i>'
				    }

        },
        dom: '<"col-12"i><"datatable-filter"f>rt<"col-12 table-footer"<"row"<"col-sm-4"l><"col-sm-4"p><"col-sm-4"B>>>',
        buttons: [ 'pdf'],

    } );
 
    table.buttons().container()
        .appendTo( '#distributorTable_filter .col-md-7:eq(0)' );
        $('.buttons-pdf span').text('Export');

   var retailertable = $('#retailerTable').DataTable( {
        lengthChange: true,
        language: {  
        	"search": "_INPUT_",
        	"searchPlaceholder": "Search by Retailer Name or Mobile Number",
        	"lengthMenu":' <div class="select-box"><select class="form-control">'+
						      '<option value="10">10 per page</option>'+
						      '<option value="20">20 per page</option>'+
						      '<option value="30">30 per page</option>'+
						      '<option value="40">40 per page</option>'+
						      '<option value="50">50 per page</option>'+
						      '<option value="-1">All</option>'+
						      '</select></div> ',
			paginate: {
				      next: '<i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>',
				      previous: '<i class="fa fa-angle-left fa-lg" aria-hidden="true"></i>'
				    }

        },
        dom: '<"col-12"i><"datatable-filter"f>rt<"col-12 table-footer"<"row"<"col-sm-4"l><"col-sm-4"p><"col-sm-4"B>>>',
        buttons: [ 'pdf'],

    } );
 
    table.buttons().container()
        .appendTo( '#retailerTable_filter .col-md-7:eq(0)' );
        $('.buttons-pdf span').text('Export');
} );
$('.user-login').click(function(){
	$('.user-options').toggle();
})
