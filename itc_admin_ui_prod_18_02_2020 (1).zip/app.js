var express = require('express');
var app = module.exports = express();
const path = require('path');

app.use('/home', function (req, res) {
    return res.sendFile(path.join(__dirname, 'public/index.html'));
  });

app.use(express.static(path.join(__dirname, 'public')));

app.all('/CorporateRetail/Admin/*', function(req, res, next) {  
	res.sendFile('public/index.html', { root: __dirname });
});

// Start listening on port 8081 on localhost
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`App listening on port ${PORT}`);
  console.log('Press Ctrl+C to quit.');
});